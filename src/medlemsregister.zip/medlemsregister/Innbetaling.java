package medlemsregister;

import java.util.Date;

public class Innbetaling {
	int ID;
	//String dato;
	String tekst;
	String innbetalingstype;
	Date dato;
	
	double sum;
	
}
