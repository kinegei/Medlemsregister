package medlemsregister;

public class Ordleit {
	Ordleit(String[] ord){
		
	}
	
	// Kva vil eg sleite etter
	// Like ord
	// Ord som inneholder ordet
	// Denne inneholder ordet
	// Ord med en bokstav forskjellig
	// Ord med 
	
	
	
}
