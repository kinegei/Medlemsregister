package medlemsregister;

import java.util.Date;

public class Person extends Aktor{

	Person(String na, String et, String adr, String postnr, String poststed,
			String ma1, String ma2, String tlf1, String tlf2, String fdato,
			String fritekst) {
		super(na, et, adr, postnr, poststed, ma1, ma2, tlf1, tlf2, fdato, fritekst);
		// TODO Auto-generated constructor stub
	}
	//Person nestepers = null;
	//String lastname;
	
}
