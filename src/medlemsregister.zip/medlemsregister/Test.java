package medlemsregister;
//import oldTests.Klasse;


 public class Test {
	public static void main(String[] args){
		Register reg = new Register();
		MainWindow win = new MainWindow(reg);
		
		/*
		Person p = new Person("Piad� godt");
		Person t = new Person("Tomas Toget");
		Person po = new Person("Polfarar");
		Person ta = new Person("Tas�");
		
		reg.leggtil(p);
		reg.leggtil(t);
		reg.leggtil(po);
		reg.leggtil(ta);
		*/
		//reg.personListe();
		
		//reg.avsluttConn();
		//Klasse tes = new Klasse();
		
		
		
	}
}
